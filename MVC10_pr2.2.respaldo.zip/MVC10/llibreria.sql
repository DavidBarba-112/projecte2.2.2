DROP DATABASE IF exists llibreria;
CREATE DATABASE llibreria;
USE llibreria   ;



CREATE TABLE rols (
    id_rol INT,
    rol VARCHAR
);


CREATE TABLE treballadors (
    id_treballador INT,
    nom VARCHAR,
    cognom1 VARCHAR,
    email VARCHAR,
    direccio VARCHAR,
    data_creacio DATE,
    id_rol INT,
    FOREIGN KEY(id_rol) REFERENCES rols(id_rol)

);



CREATE TABLE llistat_llibres(
    id_llibre INT,
    nom VARCHAR,
    num_serie INT,
    preu INT,
    categoria VARCHAR
);

CREATE TABLE llistat_llibres_venuts(
    id_llibre_venut INT,
    nom VARCHAR,
    categoria VARCHAR,
    preu INT,
    data_venta DATE
);

CREATE TABLE detall(
    id_detall INT,
    nom VARCHAR,


    id_llistat_llibres_venuts INT,
    FOREIGN KEY(id_llistat_llibres_venuts) REFERENCES llistat_llibres_venuts(id_llistat_llibres_venuts)

);


INSERT INTO rols (id_rol, rol) VALUES
    (1, 'Administrador'),
    (2, 'Empleado'),
    (3, 'Cliente');


INSERT INTO treballadors (id_treballador, nom, cognom1, email, direccio, data_creacio, id_rol) VALUES
    (1, 'Juan', 'Perez', 'juan.perez@example.com', 'Calle A, Ciudad', '2024-01-16', 1),
    (2, 'Maria', 'Gomez', 'maria.gomez@example.com', 'Calle B, Ciudad', '2024-01-16', 2),
    (3, 'Carlos', 'Rodriguez', 'carlos.rodriguez@example.com', 'Calle C, Ciudad', '2024-01-16', 2);


INSERT INTO llistat_llibres (id_llibre, nom, num_serie, preu, categoria) VALUES
    (1, 'El señor de los anillos', 12345, 25, 'Fantasía'),
    (2, '1984', 67890, 20, 'Ciencia Ficción'),
    (3, 'Cien años de soledad', 54321, 30, 'Realismo Mágico');


INSERT INTO llistat_llibres_venuts (id_llibre_venut, nom, categoria, preu, data_venta) VALUES
    (1, '1984', 'Ciencia Ficción', 20, '2024-01-16'),
    (2, 'Cien años de soledad', 'Realismo Mágico', 30, '2024-01-15');


