<?php

print_r($consulta)

?>