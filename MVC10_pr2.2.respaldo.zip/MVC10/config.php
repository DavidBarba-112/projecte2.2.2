<?php
$config = Config::singleton();
 
$config->set('controllersFolder', 'controllers/');
$config->set('modelsFolder', 'models/');
$config->set('viewsFolder', 'views/');
 
$config->set('dbhost', 'localhost');
$config->set('dbname', 'mercadona');
$config->set('dbuser', 'pma');
$config->set('dbpass', 'P@ssw0rd');
?>